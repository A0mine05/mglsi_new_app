from app import create_app

app = create_app()  # Appel de la fonction pour créer l'application

if __name__ == "__main__":
    # Démarrer l'application en mode débogage
    print("Application en cours d'exécution...")
    app.run(debug=True)
