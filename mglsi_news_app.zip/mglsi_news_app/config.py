import os

# Configuration de l'application
class Config:
    # URI de la base de données (à adapter selon vos paramètres)
    SQLALCHEMY_DATABASE_URI = 'mysql+mysqlconnector://root:@localhost/mglsi_news'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    # Clé secrète pour les sessions
    SECRET_KEY = os.urandom(24)
