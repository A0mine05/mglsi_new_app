from .models import Article

# Fonction pour récupérer les articles par catégorie
def obtenir_articles_par_categorie(categorie_libelle):
    return Article.query.join(Article.categorie_relation).filter_by(libelle=categorie_libelle).all()
