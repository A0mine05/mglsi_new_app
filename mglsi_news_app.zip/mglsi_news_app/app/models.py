# from . import db

# # Définir le modèle de données pour les articles
# class Article(db.Model):
#     __tablename__ = 'Article'
#     id = db.Column(db.Integer, primary_key=True)
#     titre = db.Column(db.String(255))
#     contenu = db.Column(db.Text)
#     categorie = db.Column(db.String(255))


from . import db

# Définir le modèle de données pour les articles
class Article(db.Model):
    __tablename__ = 'Article'
    id = db.Column(db.Integer, primary_key=True)
    titre = db.Column(db.String(255))
    contenu = db.Column(db.Text)
    dateCreation = db.Column(db.DateTime, default=db.func.now())
    dateModification = db.Column(db.DateTime, default=db.func.now(), onupdate=db.func.now())
    categorie = db.Column(db.Integer, db.ForeignKey('Categorie.id'))
    categorie_relation = db.relationship('Categorie', back_populates='articles')

# Définir le modèle de données pour les catégories
class Categorie(db.Model):
    __tablename__ = 'Categorie'
    id = db.Column(db.Integer, primary_key=True)
    libelle = db.Column(db.String(20))
    articles = db.relationship('Article', back_populates='categorie_relation')
