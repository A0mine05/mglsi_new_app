# from flask import Flask
# from flask_sqlalchemy import SQLAlchemy
# from config import Config

# # Initialiser SQLAlchemy
# db = SQLAlchemy()

# def create_app():
#     # Créer l'application Flask
#     app = Flask(__name__)
#     # Charger la configuration depuis le fichier config
#     app.config.from_object(Config)

#     # Initialiser l'extension de base de données avec l'application
#     db.init_app(app)

#     with app.app_context():
#         from . import views  # Importer les vues pour enregistrer les routes

#     return app

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from config import Config

# Initialiser SQLAlchemy
db = SQLAlchemy()

def create_app():
    # Créer l'application Flask
    app = Flask(__name__)
    # Charger la configuration depuis le fichier config
    app.config.from_object(Config)

    # Initialiser l'extension de base de données avec l'application
    db.init_app(app)

    with app.app_context():
        from . import views  # Importer les vues pour enregistrer les routes
        db.create_all()  # Créer les tables dans la base de données si elles n'existent pas

    return app
