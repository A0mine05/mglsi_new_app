from flask import render_template, current_app as app
from .controllers import obtenir_articles_par_categorie
from .models import Article  # importer le modèle Article

@app.route('/')
def index():
    # Rendre la page d'accueil
    print("Accès à la page d'accueil")
    articles = Article.query.all()  # Récupérer tous les articles pour l'accueil
    return render_template('index.html', articles=articles)

@app.route('/sport')
def sport():
    # Récupérer les articles de la catégorie "Sport"
    print("Accès à la page sport")
    articles = obtenir_articles_par_categorie('Sport')
    return render_template('sport.html', articles=articles)

@app.route('/sante')
def sante():
    # Récupérer les articles de la catégorie "Santé"
    print("Accès à la page santé")
    articles = obtenir_articles_par_categorie('Santé')
    return render_template('sante.html', articles=articles)

@app.route('/education')
def education():
    # Récupérer les articles de la catégorie "Éducation"
    print("Accès à la page education")
    articles = obtenir_articles_par_categorie('Éducation')
    return render_template('education.html', articles=articles)

@app.route('/politique')
def politique():
    # Récupérer les articles de la catégorie "Politique"
    print("Accès à la page politique")
    articles = obtenir_articles_par_categorie('Politique')
    return render_template('politique.html', articles=articles)
